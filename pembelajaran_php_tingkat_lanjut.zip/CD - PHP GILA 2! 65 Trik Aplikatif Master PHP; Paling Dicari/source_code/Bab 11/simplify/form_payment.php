<html>
	<head>
		<meta content="text/html;charset=utf-8" http-equiv="Content-Type">
		<meta content="utf-8" http-equiv="encoding">
		<script type="text/javascript" src="https://www.simplify.com/commerce/simplify.pay.js"></script>
	</head>
<body>
<button data-sc-key="KEY_ANDA"
	data-name="CV. ASFA Solution"
	data-description="Payment Invoice ID : ASFA-171289178178"
	data-reference="ASFA-171289178178"
	data-amount="5700000"
	data-color="#12B830">
	Pay Now
</button>
</body>
</html>