<?php
// Database
$dbHost = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "dbphpgila";

// Connect with the database
$connect = mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);
?>